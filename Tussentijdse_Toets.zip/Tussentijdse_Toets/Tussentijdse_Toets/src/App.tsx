import { createBrowserRouter, Router, RouterProvider } from "react-router-dom";
import "./App.css";
import Oefening1 from "./components/Oefening1/Oefening1";
import Oefening2 from "./components/Oefening2/Oefening2";
import Oefening3 from "./components/Oefening3/Oefening3";
// code werkt niet!
function App() {
  const router = createBrowserRouter([
    {
      path: "/",
      element: <Oefening1 />,
      children: [
        {
          path: "",
          element: <Oefening1 />,
        },
        {
          path: "Oefening2",
          element: <Oefening2 />,
        },
        {
          path: "Oefening3",
          element: <Oefening3 />,
        },
      ],
    },
  ]);

  return (
    <>
      <RouterProvider router={router} />
    </>
  );
}

export default App;
