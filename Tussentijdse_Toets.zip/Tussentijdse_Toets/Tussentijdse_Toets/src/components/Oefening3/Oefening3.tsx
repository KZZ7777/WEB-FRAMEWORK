import { useState } from "react";

const Oefening3 = () => {
  const [counter, setCounter] = useState("0");

  return (
    <>
      <p>{counter}</p>
      
    </>
  );
};

export default Oefening3;
