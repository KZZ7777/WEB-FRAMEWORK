const DetailPage = () => {
  return <></>;
};

export default DetailPage;
