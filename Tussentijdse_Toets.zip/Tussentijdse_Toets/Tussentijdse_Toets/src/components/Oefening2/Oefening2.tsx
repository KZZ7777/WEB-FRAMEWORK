import { useEffect, useState } from "react";
import { Duckie, DuckieList } from "../../types";
const Oefening2 = () => {
  const [duckie, setDuckie] = useState<Duckie[]>([]);
  const [error, setError] = useState<Error | null>(null);
  const [loading, setLoading] = useState<boolean>(false);

  const LoadFetch = async () => {
    try {
      setLoading(true);
      let response = await fetch(
        "https://raw.githubusercontent.com/similonap/json/refs/heads/master/duckies/duckies.json"
      );
      if (!response.ok) {
        throw new Error("Something went wrong fetching data");
      }

      let data: DuckieList = await response.json();
      setDuckie(data.results);
    } catch (err) {
      setError(err as Error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    LoadFetch();
  }, []);

  return (
    <>
      {loading && (
        <div>
          <li> {duckie.map((duck) => duck.image)}</li>
        </div>
      )}
    </>
  );
};

export default Oefening2;
