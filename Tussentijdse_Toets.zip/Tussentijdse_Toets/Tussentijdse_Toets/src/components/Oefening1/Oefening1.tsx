import { NavLink } from "react-router-dom";
import styles from "./Oefening.module.css"

NavLink
const Oefening1 = () => {
  return <>
    <div>
        <header>
            <nav>
                <ul>
                    <li> <NavLink className={({isActive}) => isActive ? styles.active : styles.notactive} to="/">Oefening 1</NavLink></li>
                    <li><NavLink className={({isActive}) => isActive ? styles.active : styles.notactive}to="/oefening2">Oefening 2</NavLink></li>
                    <li><NavLink className={({isActive}) => isActive ? styles.active : styles.notactive}to="/oefening3">Oefening 3</NavLink></li>
                </ul>
            </nav>
        </header>
    </div>
  
    
  </>;
};


export default Oefening1