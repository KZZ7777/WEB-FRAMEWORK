import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  Alert,
  ScrollView,
} from "react-native";
import { useLocalSearchParams, useNavigation } from "expo-router";
import { useEffect, useState } from "react";
import * as ImagePicker from "expo-image-picker";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";

export default function CarDetails() {
  const { car } = useLocalSearchParams();
  const data = JSON.parse(car as string);
  const navigation = useNavigation();
  const [pickedImages, setPickedImages] = useState<string[]>([]);
  const storageKey = `car-images-${data.id ?? data.name}`;

  // laadt opgeslagen afbeeldingen uit AsyncStorage
  const loadSavedImages = async () => {
    const stored = await AsyncStorage.getItem(storageKey);
    if (stored) {
      setPickedImages(JSON.parse(stored));
    }
  };

  useEffect(() => {
    loadSavedImages();
  }, []);

  // configureert de header (titel, kleuren, knoppen)
  useEffect(() => {
    navigation.setOptions({
      headerShown: true,
      title: data.name,
      headerStyle: {
        backgroundColor: "rgb(14,17,22)",
      },
      headerTitleStyle: {
        color: "white",
        fontWeight: "900",
        fontSize: 20,
      },
      headerTintColor: "white",
      // terug knop links
      headerLeft: () => (
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={{ paddingLeft: 12 }}
        >
          <Ionicons name="chevron-back" size={28} color="white" />
        </TouchableOpacity>
      ),

      // camera knop rechts in de header
      headerRight: () => (
        <TouchableOpacity onPress={takePhoto} style={{ marginRight: 12 }}>
          <Ionicons name="camera-outline" size={24} color="rgb(255,72,72)" />
        </TouchableOpacity>
      ),
    });
  }, [navigation]);

  // neemt foto met de camera en slaat ze op
  const takePhoto = async () => {
    const permission = await ImagePicker.requestCameraPermissionsAsync(); // vraagt camera permissie
    if (!permission.granted) {
      Alert.alert("Camera nodig", "Geef toegang tot je camera.");
      return;
    }
    // opent camera
    const result = await ImagePicker.launchCameraAsync({
      quality: 0.9,
      allowsEditing: true,
    });

    if (result.canceled) return;

    // Haalt bestaande foto's op en voeg nieuwe toe
    const stored = await AsyncStorage.getItem(storageKey);
    const existing = stored ? JSON.parse(stored) : [];
    const updated = [...existing, result.assets[0].uri];
    setPickedImages(updated);
    await AsyncStorage.setItem(storageKey, JSON.stringify(updated));
  };

  // kiest een afbeelding uit de galerij en slaat op
  const pickImage = async () => {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync(); // vraagt gallerij permissie
    if (!permission.granted) {
      Alert.alert("Toegang nodig", "Geef toegang tot je foto's.");
      return;
    }
    // opent fotobibliotheek
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ["images"],
      allowsEditing: true,
      aspect: [16, 9],
      quality: 0.9,
    });

    if (result.canceled) return;
    // voegt geselecteerde foto toe aan bestaande lijst
    const stored = await AsyncStorage.getItem(storageKey);
    const existing = stored ? JSON.parse(stored) : [];
    const updated = [...existing, result.assets[0].uri];
    setPickedImages(updated);
    await AsyncStorage.setItem(storageKey, JSON.stringify(updated));
  };

  // verwijdert een afbeelding na bevestiging
  const deleteImage = async (index: number) => {
    Alert.alert("Verwijderen", "Wil je deze foto verwijderen?", [
      { text: "Annuleren", style: "cancel" },
      {
        text: "Verwijderen",
        style: "destructive",
        onPress: async () => {
          const updated = pickedImages.filter((_, i) => i !== index);
          setPickedImages(updated);
          await AsyncStorage.setItem(storageKey, JSON.stringify(updated));
        },
      },
    ]);
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "rgb(14,17,22)" }}>
      <ScrollView
        contentContainerStyle={styles.container}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.infoCard}>
          <View style={styles.logoWrapper}>
            <Image
              source={{ uri: data.logo }}
              style={[
                styles.logo,
                data.name.toLowerCase().includes("mercedes")
                  ? { tintColor: "rgba(210,210,220,0.65)" }
                  : null,
              ]}
            />
          </View>

          <Text style={styles.name}>{data.name}</Text>

          <View style={styles.metaRow}>
            <Ionicons name="globe-outline" size={16} color="rgb(255,72,72)" />
            <Text style={styles.infoText}>
              Land: {data.country || "Onbekend"}
            </Text>
          </View>

          <View style={styles.metaRow}>
            <Ionicons
              name="business-outline"
              size={16}
              color="rgb(255,72,72)"
            />
            <Text style={styles.infoText}>
              Stad:
              {typeof data.city === "string"
                ? data.city
                : data.city?.name || "Onbekend"}
            </Text>
          </View>
        </View>

        <Text style={styles.collectionTitle}>Mijn collectie</Text>

        <View style={styles.collectionBox}>
          {pickedImages.length === 0 ? (
            <Text style={styles.emptyCollection}>
              Nog geen foto's toegevoegd
            </Text>
          ) : (
            <View style={styles.imagesGrid}>
              {pickedImages.map((img, index) => (
                <TouchableOpacity
                  key={index}
                  onPress={() => deleteImage(index)}
                  style={styles.imageWrapper}
                >
                  <Image source={{ uri: img }} style={styles.userImage} />
                </TouchableOpacity>
              ))}
            </View>
          )}
        </View>

        <TouchableOpacity style={styles.button} onPress={pickImage}>
          <Ionicons name="camera-outline" size={20} color="rgb(255,72,72)" />
          <Text style={styles.buttonText}>Voeg eigen foto toe</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: "rgb(14,17,22)",
  },
  infoCard: {
    marginTop: 10,
    width: "100%",
    padding: 26,
    borderRadius: 26,
    alignItems: "center",
    backgroundColor: "rgb(20,25,35)",
    borderWidth: 1,
    borderColor: "rgba(255,72,72,0.25)",
    shadowColor: "rgb(255,72,72)",
    shadowOpacity: 0.3,
    shadowRadius: 28,
    elevation: 18,
    marginBottom: 30,
  },
  logoWrapper: {
    width: 240,
    height: 140,
    backgroundColor: "rgb(30,36,48)",
    borderRadius: 24,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 20,
    borderWidth: 1.5,
    borderColor: "rgba(255,72,72,0.25)",
  },
  logo: {
    width: 200,
    height: 110,
    resizeMode: "contain",
  },
  name: {
    fontSize: 26,
    fontWeight: "900",
    letterSpacing: 2,
    color: "rgb(249,250,251)",
    marginBottom: 16,
  },
  metaRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 8,
    gap: 6,
  },
  infoText: {
    fontSize: 15,
    color: "rgb(156,163,175)",
  },
  collectionTitle: {
    fontSize: 20,
    fontWeight: "800",
    letterSpacing: 2,
    color: "rgb(255,72,72)",
    marginBottom: 14,
  },
  collectionBox: {
    width: "100%",
    padding: 16,
    borderRadius: 22,
    backgroundColor: "rgb(20,25,35)",
    borderWidth: 1.5,
    borderColor: "rgba(255,72,72,0.25)",
    shadowOpacity: 0.25,
    shadowRadius: 22,
    elevation: 14,
    marginBottom: 28,
  },
  emptyCollection: {
    color: "rgb(156,163,175)",
    textAlign: "center",
    fontSize: 14,
  },
  imagesGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 12,
  },
  imageWrapper: {
    width: "48%",
    borderRadius: 12,
    overflow: "hidden",
    borderWidth: 1,
    borderColor: "rgba(255,72,72,0.25)",
  },
  userImage: {
    width: "100%",
    height: 140,
    resizeMode: "cover",
  },
  button: {
    width: "100%",
    paddingVertical: 18,
    borderRadius: 18,
    backgroundColor: "rgb(20,25,35)",
    borderWidth: 1,
    borderColor: "rgba(255,72,72,0.35)",
    shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.4,
    shadowRadius: 26,
    elevation: 16,
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "center",
    gap: 10,
    marginBottom: 50,
  },
  buttonText: {
    fontSize: 16,
    fontWeight: "800",
    letterSpacing: 1.5,
    color: "rgb(255,72,72)",
  },
});
