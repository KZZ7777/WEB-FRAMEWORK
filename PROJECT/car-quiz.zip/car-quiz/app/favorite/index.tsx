import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useEffect, useState } from "react";
import { router, Stack } from "expo-router";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { Cars } from "../../types";

export default function FavoritePage() {
  const [favorites, setFavorites] = useState<Cars[]>([]);

  // hier halen we de opgeslagen favorieten op uit AsyncStorage
  const loadFavorites = async () => {
    const stored = await AsyncStorage.getItem("favoriteCars");
    const favs = stored ? JSON.parse(stored) : []; // parse JSON of gebruik lege lijst als er niets is
    setFavorites(favs);
  };

  useEffect(() => {
    loadFavorites();
  }, []);

  // navigeert naar detailpagina van de geselecteerde auto
  const goToDetail = (car: Cars) => {
    router.push({
      pathname: "/favorite/carDetails",
      params: { car: JSON.stringify(car) },
    });
  };
  // verwijdert een auto uit de favorieten en update de opslag
  const removeFavorite = async (id: number) => {
    const updated = favorites.filter((car) => car.id !== id);
    setFavorites(updated);
    await AsyncStorage.setItem("favoriteCars", JSON.stringify(updated));
  };

  return (
    <>
      <Stack.Screen options={{ headerShown: false }} />
      <SafeAreaView style={styles.container}>
        <Text style={styles.title}>Jouw favorieten</Text>
        {favorites.length === 0 ? (
          <View style={styles.emptyBox}>
            <Ionicons name="heart-outline" size={34} color="rgb(255,72,72)" />
            <Text style={styles.emptyText}>
              Je hebt nog geen favorieten toegevoegd
            </Text>
          </View>
        ) : (
          <FlatList
            data={favorites}
            keyExtractor={(item) => String(item.id)}
            contentContainerStyle={styles.listContainer}
            renderItem={({ item }) => (
              <TouchableOpacity
                style={styles.card}
                activeOpacity={0.85}
                onPress={() => goToDetail(item)}
              >
                <Text style={styles.name}>{item.name}</Text>
                <TouchableOpacity
                  style={styles.deleteButton}
                  onPress={() => removeFavorite(item.id)}
                >
                  <Ionicons
                    name="trash-outline"
                    size={18}
                    color="rgb(249,250,251)"
                  />
                </TouchableOpacity>
              </TouchableOpacity>
            )}
          />
        )}
      </SafeAreaView>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgb(14,17,22)",
    padding: 20,
  },
  title: {
    color: "rgb(255,72,72)",
    fontSize: 22,
    fontWeight: "800",
    letterSpacing: 2,
    marginBottom: 22,
  },
  listContainer: {
    width: "100%",
    paddingBottom: 80,
  },
  card: {
    width: "100%",
    paddingVertical: 18,
    paddingHorizontal: 18,
    borderRadius: 18,
    marginBottom: 14,
    backgroundColor: "rgb(20,25,35)",
    borderWidth: 0,
    shadowColor: "rgba(0, 0, 0, 1)",
    shadowOpacity: 0.25,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: 8 },
    elevation: 8,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  name: {
    fontSize: 17,
    fontWeight: "800",
    letterSpacing: 1.5,
    color: "rgb(249,250,251)",
  },
  deleteButton: {
    backgroundColor: "rgb(30,36,48)",
    padding: 10,
    borderRadius: 12,
    borderWidth: 0,
    shadowColor: "rgba(0, 0, 0, 1)",
    shadowOpacity: 0.2,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
  },
  emptyBox: {
    marginTop: 120,
    alignItems: "center",
    gap: 14,
  },
  emptyText: {
    color: "rgb(156,163,175)",
    fontSize: 15,
    textAlign: "center",
    lineHeight: 22,
  },
});
