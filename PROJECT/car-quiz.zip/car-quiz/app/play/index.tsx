import React, { useEffect, useState } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import {
  View,
  Text,
  TextInput,
  Image,
  StyleSheet,
  ActivityIndicator,
  Alert,
  TouchableOpacity,
  ScrollView,
} from "react-native";
import { router, Stack } from "expo-router";
import * as Notifications from "expo-notifications";
import { Cars } from "../../types";

const maxQuestions = 10; // hier zeggen we max aantal vragen

// blobale notif instellingen
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    // toont melding op het scherm
    shouldShowAlert: true,
    shouldShowBanner: true,
    shouldShowList: true,
    shouldPlaySound: true, // speelt geluid af bij notificatie
    shouldSetBadge: false, // geen app-badge aanpassen
  }),
});

export default function CarQuizScreen() {
  const [cars, setCars] = useState<Cars[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answer, setAnswer] = useState("");
  const [loading, setLoading] = useState(true);
  const [score, setScore] = useState(0);
  const [revealProgress, setRevealProgress] = useState(0.2);

  // normaliseer tekst zodat menselijke antwoorden tellen
  const normalize = (text: string) =>
    text
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]/g, "");

  // vraagt notificatie-toestemming wanneer de pagina opent
  useEffect(() => {
    const registerForNotifications = async () => {
      const { status } = await Notifications.requestPermissionsAsync(); // vraagt permissie voor notificaties
      // toestemming geweigerd is, toont die melding van het niet is toegestaan
      if (status !== "granted") {
        Alert.alert("Melding", "Notificaties zijn niet toegestaan.");
      }
    };
    registerForNotifications();
  }, []); // wordt maar 1x uitgevoerd bij het openen van de pagina

  // haalt auto-data op en reset de quiz bij het openen van de pagina
  useEffect(() => {
    const fetchCars = async () => {
      try {
        // reset score in opslag en state
        await AsyncStorage.setItem("quizScore", "0");
        setScore(0);

        //hier gebeurt de fetch en de automerken worden opgehaald van de API
        const res = await fetch("https://sampleapis.assimilate.be/car/brands");
        let data = await res.json();
        // enkel geldige vragen
        data = data.filter(
          (c: Cars) =>
            c &&
            typeof c.name === "string" &&
            typeof c.logo === "string" &&
            c.logo.startsWith("http")
        );

        // dit zorgt voor random volgorde
        data.sort(() => Math.random() - 0.5);
        //neemt enkel het aantal vragen dat we nodig hebben
        setCars(data.slice(0, maxQuestions));
      } catch (e) {
        console.log("Fetch error:", e); // fout bij het ophalen van auto's
        Alert.alert("Fout", "Kon auto's niet laden.");
      } finally {
        setLoading(false);
      }
    };
    fetchCars();
  }, []);

  const currentCar = cars[currentIndex] || null; //hier zeggen we geef me huidige auto en als er niets is geef me null

  // Gaat naar de volgende auto of naar het resultaat-scherm
  const loadNextCar = async (newScore: number) => {
    await AsyncStorage.setItem("quizScore", JSON.stringify(newScore)); // hier slaan we de nieuwe score op

    // hier zezggen we als dit de laatste vraag is moet je direct verwijzen naar result page
    if (currentIndex + 1 >= cars.length) {
      router.push({
        pathname: "/play/resultPage",
        params: {
          score: newScore,
          total: cars.length,
        },
      });
      return;
    }
    setCurrentIndex((prev) => prev + 1); // ga naar de volgende vraag
    //hier zeggen we reset de input voor nieuwe vraag
    setAnswer("");
    setScore(newScore);
    setRevealProgress(0.2);
  };

  const checkAnswer = () => {
    if (!currentCar) return; // stop als er geen huidige auto is

    // vergelijk het antwoord met de juiste naam (zonder hoofdletters/spaties)
    const isCorrect = normalize(answer) === normalize(currentCar.name);

    // als het antwoord juist is
    if (isCorrect) {
      setRevealProgress(1); //toont het volledige logo reveal
      setTimeout(() => {
        setScore((prevScore) => {
          const newScore = prevScore + 1;
          loadNextCar(newScore);
          return newScore;
        });
      }, 600);
      return;
    }

    setRevealProgress((prev) => {
      const next = Math.min(prev + 0.2, 1); //verhoogt de reveal stap voor stap, max tot 1 (100%)

      // als alles volledig onthuld is
      if (next >= 1) {
        Alert.alert(
          "Laatste kans voorbij!",
          `Het antwoord was: ${currentCar.name}`,
          [{ text: "Verder", onPress: () => loadNextCar(score) }] // hier ga je verder zonder score te verhogen
        );
      } else {
        Alert.alert("Fout!", "Ik onthul een stukje van het logo"); //hier als nog niet alles volledig onthuld is → geef hint
      }
      return next;
    });
  };

  const handleSkip = () => loadNextCar(score); // slaagt de huidige vraag over zonder de score te verhogen

  // toont laadscherm zolang data nog laadt of er geen auto beschikbaar is
  if (loading || !currentCar) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="rgb(255,72,72)" />
      </View>
    );
  }

  return (
    <>
      <Stack.Screen
        options={{
          title: "Play",
          headerBackTitle: "",
          headerBackVisible: false,
          headerStyle: { backgroundColor: "rgb(14,17,22)" },
          headerTitleStyle: { color: "rgb(249,250,251)", fontWeight: "700" },
          headerTintColor: "rgb(249,250,251)",
          headerShadowVisible: false,
          gestureEnabled: false,
        }}
      />

      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.title}>
          Vraag {currentIndex + 1} van {cars.length}
        </Text>

        {/* logo */}
        <View style={styles.logoWrapper}>
          <Image
            source={{ uri: currentCar.logo }}
            style={[
              styles.logo,
              currentCar.name.toLowerCase().includes("mercedes")
                ? { tintColor: "rgba(220,220,230,0.65)" }
                : null,
            ]}
            // hier skippen autos die geen logo hebben
            onError={() => loadNextCar(score)}
          />
          <View style={[styles.logoOverlay, { opacity: 1 - revealProgress }]} />
        </View>

        <TextInput
          placeholder="Typ de merknaam"
          placeholderTextColor="rgb(156,163,175)"
          value={answer}
          onChangeText={setAnswer}
          style={styles.input}
          returnKeyType="done"
          onSubmitEditing={checkAnswer}
        />
        <View style={styles.buttonGroup}>
          <TouchableOpacity style={styles.button} onPress={checkAnswer}>
            <Text style={styles.buttonText}>Controleer</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.button} onPress={handleSkip}>
            <Text style={styles.buttonText}>Overslaan</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    alignItems: "center",
    flexGrow: 1,
    backgroundColor: "rgb(14,17,22)",
  },
  center: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgb(14,17,22)",
  },
  title: {
    fontSize: 18,
    fontWeight: "700",
    marginBottom: 20,
    color: "rgb(249,250,251)",
  },
  logoWrapper: {
    width: 260,
    height: 180,
    borderRadius: 22,
    backgroundColor: "rgb(30,36,48)",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 30,
    borderWidth: 1.4,
    borderColor: "rgba(255,72,72,0.25)",
    shadowColor: "rgb(255,72,72)",
    shadowOpacity: 0.32,
    shadowRadius: 28,
    elevation: 18,
  },
  logo: {
    width: 220,
    height: 140,
    resizeMode: "contain",
    zIndex: 2,
  },
  logoOverlay: {
    position: "absolute",
    width: "100%",
    height: "100%",
    backgroundColor: "rgba(0,0,0,1)",
    borderRadius: 22,
    zIndex: 3,
  },
  input: {
    width: "100%",
    padding: 16,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: "rgba(255,72,72,0.25)",
    marginBottom: 18,
    backgroundColor: "rgb(20,25,35)",
    fontSize: 16,
    color: "rgb(249,250,251)",
  },
  buttonGroup: {
    flexDirection: "row",
    gap: 12,
    width: "100%",
    justifyContent: "space-between",
  },
  button: {
    flex: 1,
    paddingVertical: 14,
    borderRadius: 12,
    backgroundColor: "rgb(20,25,35)",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "rgba(255,72,72,0.35)",
  },
  buttonText: {
    fontSize: 14,
    fontWeight: "700",
    letterSpacing: 1.5,
    color: "rgb(255,72,72)",
  },
});
