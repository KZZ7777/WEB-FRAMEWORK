import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Animated,
  Platform,
} from "react-native";
import { useLocalSearchParams, router, Stack } from "expo-router";
import { useEffect, useRef } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { supabase } from "../../lib/supabase";

export default function ResultPage() {
  const { score, total } = useLocalSearchParams();
  const numericScore = Number(score);
  const numericTotal = Number(total);
  const percentage = numericTotal > 0 ? (numericScore / numericTotal) * 100 : 0;
  const safePercentage = Math.min(Math.max(percentage, 0), 100);
  const progress = useRef(new Animated.Value(0)).current;

  //animeert de progress bar naar het behaalde percentage (wordt maar 1x uitgevoerd)
  useEffect(() => {
    Animated.timing(progress, {
      toValue: safePercentage, // dit is onze doelwaarde hoeveel we halen
      duration: 900, // animatie duur is 0.9sec
      useNativeDriver: false,
    }).start();
    postScore(numericScore, numericTotal);
  }, []);

  // zet de animatie-waarde (0–100) om naar een percentage voor de balkbreedte
  const barWidth = progress.interpolate({
    inputRange: [0, 100],
    outputRange: ["0%", "100%"],
  });

  // bepaalt de feedbacktekst op basis van je score
  const feedback =
    percentage === 100
      ? "Perfectie. Jij rijdt foutloos."
      : percentage >= 70
      ? "Jij domineert dit spel."
      : percentage >= 40
      ? "Niet slecht, maar je kan beter."
      : "Nah, dit was pijnlijk.";

  //hier zeggen we start de quiz opnieuw en reset de score
  const playAgain = async () => {
    await AsyncStorage.setItem("quizScore", "0");
    router.replace("/play");
  };

  // hier zeggen we ga terug naar homepage en reset de score
  const goHome = async () => {
    await AsyncStorage.setItem("quizScore", "0");
    router.replace({ pathname: "/" });
  };

  const postScore = async (score: number, total: number) => {
    const { error } = await supabase.from("scores").insert([
      {
        score,
        total,
      },
    ]);

    if (error) {
      console.log("POST error:", error.message);
    } else {
      console.log("Score opgeslagen ");
    }
  };
  return (
    <>
      <Stack.Screen
        options={{
          headerShown: false,
          headerBackTitle: "",
          headerBackVisible: false,
          gestureEnabled: false,
        }}
      />
      <View style={styles.customHeader}>
        <Text style={styles.customHeaderTitle}>Resultaat</Text>
      </View>

      <View style={styles.container}>
        <View style={styles.card}>
          <Text style={styles.title}>Resultaat</Text>

          <View style={styles.circle}>
            <Text style={styles.circleScore}>
              {numericScore}/{numericTotal}
            </Text>
          </View>

          <View style={styles.meterBackground}>
            <Animated.View style={[styles.meterFill, { width: barWidth }]} />
          </View>

          <Text style={styles.feedbackText}>{feedback}</Text>
        </View>

        <View style={styles.actionRow}>
          <TouchableOpacity style={styles.primaryBtn} onPress={playAgain}>
            <Text style={styles.primaryBtnText}>Opnieuw spelen</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.secondaryBtn} onPress={goHome}>
            <Text style={styles.secondaryBtnText}>Terug naar Home</Text>
          </TouchableOpacity>
        </View>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  customHeader: {
    paddingTop: Platform.OS === "ios" ? 60 : 40,
    paddingBottom: 20,
    alignItems: "center",
    backgroundColor: "rgba(3, 4, 5, 1)",
  },
  customHeaderTitle: {
    color: "rgba(229, 231, 235, 1)",
    fontSize: 22,
    fontWeight: "900",
  },
  container: {
    flex: 1,
    paddingHorizontal: 22,
    paddingTop: 20,
    backgroundColor: "rgba(3, 4, 5, 1)",
    justifyContent: "space-between",
  },
  card: {
    backgroundColor: "rgba(20, 25, 35, 1)",
    padding: 28,
    borderRadius: 28,
    borderColor: "rgba(255,72,72,0.25)",
    borderWidth: 1,
    shadowColor: "rgb(255,72,72)",
    shadowOpacity: 0.25,
    shadowRadius: 40,
    elevation: 15,
    alignItems: "center",
    marginTop: 10,
  },
  title: {
    fontSize: 24,
    fontWeight: "900",
    color: "rgba(229, 231, 235, 1)",
    marginBottom: 20,
  },
  circle: {
    width: 140,
    height: 140,
    borderRadius: 70,
    borderWidth: 1,
    borderColor: "rgba(255,72,72,0.35)",
    backgroundColor: "rgba(255,72,72,0.1)",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 26,
  },
  circleScore: {
    color: "rgb(255,72,72)",
    fontSize: 30,
    fontWeight: "900",
  },
  meterBackground: {
    width: "100%",
    height: 12,
    backgroundColor: "rgba(31, 35, 43, 1)",
    borderRadius: 8,
    overflow: "hidden",
    marginBottom: 18,
  },
  meterFill: {
    height: "100%",
    backgroundColor: "rgb(255,72,72)",
    borderRadius: 8,
  },
  feedbackText: {
    color: "rgba(229, 231, 235, 1)",
    fontSize: 16,
    marginTop: 10,
    textAlign: "center",
    lineHeight: 22,
    fontWeight: "600",
  },
  actionRow: {
    marginBottom: 40,
    gap: 16,
  },
  primaryBtn: {
    backgroundColor: "rgb(255,72,72)",
    paddingVertical: 16,
    borderRadius: 16,
    alignItems: "center",
  },
  primaryBtnText: {
    color: "rgba(14, 17, 22, 1)",
    fontSize: 16,
    fontWeight: "900",
  },
  secondaryBtn: {
    borderColor: "rgba(255,72,72,0.25)",
    borderWidth: 1,
    paddingVertical: 16,
    borderRadius: 16,
    alignItems: "center",
    backgroundColor: "rgba(20, 25, 35, 1)",
  },
  secondaryBtnText: {
    color: "rgb(255,72,72)",
    fontSize: 16,
    fontWeight: "700",
  },
});
