import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Platform,
} from "react-native";
import { Stack, router } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { useEffect, useState } from "react";

// array van quotes
const quotes = [
  "Snelheid wint geen races. Focus wel.",
  "Discipline verslaat talent als talent lui is.",
  "Perfectie is saai. Controle is stijl.",
  "Je herkent een leider aan wat hij weigert.",
];

export default function Home() {
  const [dailyQuote, setDailyQuote] = useState("");

  useEffect(() => {
    const randomQuote = Math.floor(Math.random() * quotes.length);
    setDailyQuote(quotes[randomQuote]);
  }, []);

  return (
    <>
      <Stack.Screen
        options={{
          title: "Home",
          headerBackVisible: false,
          headerBackTitle: "",
          headerStyle: { backgroundColor: "rgb(14,17,22)" },
          headerTitleStyle: {
            color: "rgb(249,250,251)",
            fontWeight: "700",
          },
          headerTintColor: "rgb(249,250,251)",
          headerShadowVisible: false,
          gestureEnabled: false,
        }}
      />

      <ScrollView contentContainerStyle={styles.container}>
        <View style={styles.hero}>
          <Text style={styles.heroTitle}>CAR QUIZ</Text>
          <Text style={styles.heroSub}>Test je automerken kennis</Text>
        </View>

        {/* play-screen */}
        <TouchableOpacity
          style={styles.mainButton}
          onPress={() => router.push("/play")}
        >
          <Text style={styles.mainButtonText}>▶ PLAY</Text>
        </TouchableOpacity>
        <View style={styles.quoteWrapper}>
          <View style={styles.quoteCard}>
            <Text style={styles.quoteHeader}>Quote of the Day</Text>
            <Text style={styles.quoteText}>"{dailyQuote}"</Text>
          </View>
        </View>

        {/* favorite-screen */}
        <View style={styles.actionRow}>
          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => router.push("/favorite")}
          >
            <Ionicons name="heart" size={18} color="rgb(255,72,72)" />
            <Text style={styles.actionText}>Favorieten</Text>
          </TouchableOpacity>

          {/* car-info screen */}
          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => router.push("/car-info")}
          >
            <Ionicons
              name="information-circle"
              size={18}
              color="rgb(255,72,72)"
            />
            <Text style={styles.actionText}>Car Info</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    paddingHorizontal: 20,
    paddingTop: Platform.OS === "ios" ? 60 : 30,
    paddingBottom: 60,
    backgroundColor: "rgb(14,17,22)",
  },
  hero: {
    height: 180,
    borderRadius: 26,
    backgroundColor: "rgb(20,25,35)",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 32,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.08)",
    shadowColor: "rgb(255,72,72)",
    shadowOpacity: 0.25,
    shadowRadius: 30,
    elevation: 18,
  },
  heroTitle: {
    fontSize: 32,
    fontWeight: "900",
    letterSpacing: 3,
    color: "rgb(249,250,251)",
  },
  heroSub: {
    fontSize: 14,
    marginTop: 6,
    color: "rgb(255,72,72)",
  },
  mainButton: {
    width: "100%",
    paddingVertical: 18,
    borderRadius: 16,
    backgroundColor: "rgb(20,25,35)",
    alignItems: "center",
    marginBottom: 40,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.08)",
  },
  mainButtonText: {
    color: "rgb(249,250,251)",
    fontWeight: "800",
    letterSpacing: 2,
    fontSize: 16,
  },
  quoteWrapper: {
    width: "100%",
    alignItems: "center",
    marginBottom: 70,
  },
  quoteHeader: {
    color: "rgb(255,72,72)",
    fontWeight: "900",
    fontSize: 14,
    textAlign: "center",
    marginBottom: 6,
    letterSpacing: 1.2,
  },
  quoteCard: {
    width: "100%",
    padding: 26,
    borderRadius: 24,
    backgroundColor: "rgb(20,25,35)",
    borderWidth: 1,
    borderColor: "rgba(255,72,72,0.25)",
    shadowColor: "rgb(255,72,72)",
    shadowOpacity: 0.18,
    shadowRadius: 40,
    elevation: 12,
  },
  quoteText: {
    color: "rgb(249,250,251)",
    fontSize: 16,
    fontWeight: "600",
    textAlign: "center",
    letterSpacing: 0.6,
    lineHeight: 24,
  },
  actionRow: {
    flexDirection: "row",
    gap: 12,
    marginTop: 180,
  },
  actionButton: {
    flex: 1,
    paddingVertical: 18,
    borderRadius: 18,
    backgroundColor: "rgb(20,25,35)",
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "center",
    gap: 8,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.08)",
  },
  actionText: {
    color: "rgb(249,250,251)",
    fontWeight: "700",
  },
});
