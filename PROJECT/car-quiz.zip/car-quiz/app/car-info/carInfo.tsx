import {
  View,
  Text,
  Image,
  StyleSheet,
  ActivityIndicator,
  Alert,
  TouchableOpacity,
  Linking,
} from "react-native";
import { Stack, useLocalSearchParams } from "expo-router";
import { useEffect, useState } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Cars } from "../../types";
import * as Notifications from "expo-notifications";

export default function CarInfo() {
  const { id } = useLocalSearchParams();
  const [car, setCar] = useState<Cars | null>(null);
  const [loading, setLoading] = useState(true);
  const [isFavorite, setIsFavorite] = useState(false);

  // haalt info op van 1 specifieke auto op wanneer het id verandert
  useEffect(() => {
    const fetchCarInfo = async () => {
      try {
        const res = await fetch("https://sampleapis.assimilate.be/car/brands");
        const data: Cars[] = await res.json();
        const selected = data.find((c) => String(c.id) === String(id)); // zoekt de auto met het juiste id

        // als de auto niet bestaat → foutmelding
        if (!selected) {
          Alert.alert("Fout", "Auto niet gevonden");
          return;
        }
        setCar(selected);

        // controleert of deze auto al in favorieten zit
        const stored = await AsyncStorage.getItem("favoriteCars");
        const favs = stored ? JSON.parse(stored) : [];
        setIsFavorite(favs.some((f: Cars) => f.id === selected.id));
      } catch {
        Alert.alert("Fout", "Kon autogegevens niet laden.");
      } finally {
        setLoading(false);
      }
    };
    fetchCarInfo();
  }, [id]);

  // voegt een auto toe aan favorieten of verwijdert hem
  const toggleFavorite = async () => {
    // stop als er geen auto is
    if (!car) return;

    // haalt huidige favorieten op uit AsyncStorage
    const stored = await AsyncStorage.getItem("favoriteCars");
    let favs: Cars[] = stored ? JSON.parse(stored) : [];

    // Check of de auto al in favorieten zit
    const exists = favs.some((f) => f.id === car.id);

    // bepaalt notificatie-inhoud op basis van actie
    const notification = exists
      ? {
          title: "Favoriet verwijderd 💔",
          body: `${car.name} is verwijderd uit je favorieten.`,
        }
      : {
          title: "Toegevoegd aan favorieten ❤️",
          body: `${car.name} is toegevoegd aan je favorieten.`,
        };

    //  favorietenlijst uodaten
    favs = exists ? favs.filter((f) => f.id !== car.id) : [...favs, car];
    setIsFavorite(!exists);

    // toon notificatie
    await Notifications.scheduleNotificationAsync({
      content: { ...notification, sound: true },
      trigger: null,
    });

    // slax aangepaste favorietenlijst op
    await AsyncStorage.setItem("favoriteCars", JSON.stringify(favs));
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="rgb(255,72,72)" />
      </View>
    );
  }

  if (!car) {
    return (
      <View style={styles.center}>
        <Text style={styles.info}>Geen info gevonden</Text>
      </View>
    );
  }

  return (
    <>
      <Stack.Screen options={{ headerShown: false }} />
      <SafeAreaView style={styles.container}>
        <View style={styles.heroCard}>
          {/*favo button  */}
          <TouchableOpacity style={styles.favoriteBtn} onPress={toggleFavorite}>
            <Ionicons
              name={isFavorite ? "heart" : "heart-outline"}
              size={26}
              color={isFavorite ? "rgb(255,72,72)" : "rgb(180,180,180)"}
            />
          </TouchableOpacity>
          {/* logo */}
          <View style={styles.logoGlow}>
            <Image
              source={{ uri: car.logo }}
              style={[
                styles.logo,
                car.name.toLowerCase().includes("mercedes")
                  ? { tintColor: "rgba(210,210,220,0.65)" }
                  : null,
              ]}
            />
          </View>
          <Text style={styles.name}>{car.name}</Text>
          <View style={styles.infoBlock}>
            <Ionicons name="globe-outline" size={18} color="rgb(255,72,72)" />
            <Text style={styles.info}> {car.country}</Text>
          </View>
          <View style={styles.infoBlock}>
            <Ionicons name="time-outline" size={18} color="rgb(255,72,72)" />
            <Text style={styles.info}> {car.founded}</Text>
          </View>
          <View style={styles.infoBlock}>
            <Ionicons
              name="business-outline"
              size={18}
              color="rgb(255,72,72)"
            />
            <Text style={styles.info}> {car.city?.name || "Onbekend"}</Text>
          </View>
          {car.website && (
            <TouchableOpacity
              style={styles.websiteBtn}
              onPress={() => Linking.openURL(car.website!)}
            >
              <Ionicons name="link-outline" size={18} color="#0E1116" />
              <Text style={styles.websiteText}>Bezoek website</Text>
            </TouchableOpacity>
          )}
        </View>
      </SafeAreaView>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgb(14,17,22)",
    justifyContent: "center",
    alignItems: "center",
  },
  center: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgb(14,17,22)",
  },
  heroCard: {
    width: "90%",
    paddingVertical: 36,
    paddingHorizontal: 26,
    borderRadius: 30,
    backgroundColor: "rgb(20,25,35)",
    borderWidth: 1,
    borderColor: "rgba(255,72,72,0.25)",
    shadowOffset: { width: 0, height: 20 },
    shadowOpacity: 0.3,
    shadowRadius: 40,
    elevation: 20,
    alignItems: "center",
  },
  favoriteBtn: {
    position: "absolute",
    top: 18,
    right: 18,
  },
  logoGlow: {
    width: 240,
    height: 140,
    borderRadius: 28,
    backgroundColor: "rgb(30,36,48)",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 24,
    shadowColor: "rgb(255,72,72)",
    shadowOpacity: 0.45,
    shadowRadius: 30,
    elevation: 18,
    borderWidth: 1.5,
    borderColor: "rgba(255,72,72,0.22)",
  },
  logo: {
    width: 190,
    height: 110,
    resizeMode: "contain",
  },
  name: {
    fontSize: 28,
    fontWeight: "900",
    letterSpacing: 2,
    color: "rgb(255,72,72)",
    marginBottom: 22,
  },
  infoBlock: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 12,
    gap: 8,
  },
  info: {
    fontSize: 16,
    color: "rgb(200,200,200)",
  },
  websiteBtn: {
    marginTop: 22,
    backgroundColor: "rgb(255,72,72)",
    paddingVertical: 14,
    paddingHorizontal: 26,
    borderRadius: 20,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    shadowColor: "rgb(255,72,72)",
    shadowOpacity: 0.3,
    shadowRadius: 20,
    elevation: 12,
  },
  websiteText: {
    fontSize: 15,
    fontWeight: "800",
    letterSpacing: 1.2,
    color: "#0E1116",
  },
});
