import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  Image,
  StyleSheet,
  TextInput,
} from "react-native";
import { useEffect, useState } from "react";
import { router, Stack } from "expo-router";
import { SafeAreaView } from "react-native-safe-area-context";
import { Cars } from "../../types";

export default function Index() {
  const [cars, setCars] = useState<Cars[]>([]);
  const [filteredCars, setFilteredCars] = useState<Cars[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  // haalt alle automerken op wanneer de pagina opent
  useEffect(() => {
    const fetchCars = async () => {
      try {
        const res = await fetch("https://sampleapis.assimilate.be/car/brands");
        let data: Cars[] = await res.json();
        setCars(data);
        setFilteredCars(data);
      } catch {
        Alert.alert("Fout", "Kon auto's niet laden.");
      } finally {
        setLoading(false);
      }
    };
    fetchCars();
  }, []);

  // zoek logica, deze filtert auto's op naam
  useEffect(() => {
    const filtered = cars.filter((car: Cars) =>
      car.name.toLowerCase().includes(search.toLowerCase())
    );
    setFilteredCars(filtered); // lijst updaten die op het scherm komt
  }, [search, cars]); // draait opnieuw bij zoekinput of nieuwe data

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="rgb(249,250,251)" />
      </View>
    );
  }

  return (
    <>
      <Stack.Screen options={{ headerShown: false }} />

      <SafeAreaView style={styles.container}>
        {/* zoekbalkje */}
        <TextInput
          placeholder="Zoek automerk..."
          placeholderTextColor="rgb(156,163,175)"
          value={search}
          onChangeText={setSearch}
          style={styles.search}
        />
        <FlatList
          data={filteredCars}
          keyExtractor={(item) => String(item.id)}
          showsVerticalScrollIndicator={false}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={styles.card}
              onPress={() =>
                router.push({
                  pathname: "/car-info/carInfo",
                  params: { id: item.id },
                })
              }
            >
              <Image source={{ uri: item.logo }} style={styles.logo} />
              <View style={styles.textBox}>
                <Text style={styles.name}>{item.name}</Text>
                <Text style={styles.country}>{item.country}</Text>
              </View>
            </TouchableOpacity>
          )}
        />
      </SafeAreaView>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: "rgb(14,17,22)",
  },
  center: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgb(14,17,22)",
  },
  search: {
    width: "100%",
    paddingVertical: 14,
    paddingHorizontal: 18,
    borderRadius: 16,
    backgroundColor: "rgb(20,25,35)",
    color: "rgb(249,250,251)",
    marginBottom: 16,
    fontSize: 15,
  },
  card: {
    flexDirection: "row",
    alignItems: "center",
    padding: 14,
    marginBottom: 14,
    borderRadius: 18,
    backgroundColor: "rgb(20,25,35)",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.25,
    shadowRadius: 14,
    elevation: 8,
  },
  logo: {
    width: 60,
    height: 40,
    resizeMode: "contain",
    marginRight: 14,
  },
  textBox: {
    flex: 1,
  },
  name: {
    fontSize: 18,
    fontWeight: "800",
    letterSpacing: 1.5,
    color: "rgb(249,250,251)",
    marginBottom: 4,
  },
  country: {
    fontSize: 14,
    color: "rgb(156,163,175)",
  },
});
