export interface Cars {
    id:number,
    name: string,
    country:string,
    founded: number,
    city: City,
    website: string,
    logo: string
}

export interface City {
  name: string;
  latitude: number;
  longitude: number;
}



